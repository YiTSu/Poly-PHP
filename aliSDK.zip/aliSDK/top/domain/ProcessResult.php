<?php

/**
 * 淘宝文本算法返回数据结构
 * @author auto create
 */
class ProcessResult
{
	
	/** 
	 * 返回文本处理内容
	 **/
	public $top_result;
	
	/** 
	 * 返回结果为true则运行成功，为false则运行失败
	 **/
	public $top_status;	
}
?>