<?php

/**
 * result
 * @author auto create
 */
class Result
{
	
	/** 
	 * code
	 **/
	public $code;
	
	/** 
	 * 是否存在
	 **/
	public $model;
	
	/** 
	 * 返回描述
	 **/
	public $msg;
	
	/** 
	 * 是否异常
	 **/
	public $success;	
}
?>