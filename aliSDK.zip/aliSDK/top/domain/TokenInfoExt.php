<?php

/**
 * token info中的扩展字段
 * @author auto create
 */
class TokenInfoExt
{
	
	/** 
	 * open account当前token info中open account id对应的open account信息
	 **/
	public $open_account;	
}
?>